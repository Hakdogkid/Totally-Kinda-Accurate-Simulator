energy+=5
instance_destroy()